---@class EnemyBattler : EnemyBattler
local EnemyBattler, super = HookSystem.hookScript(EnemyBattler)

return EnemyBattler